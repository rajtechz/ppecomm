import React from 'react'

function Pages() {
  return (
    <div>
      
    </div>
  )
}

export default Pages
