import img1 from "../../assets/newTrending/img1.webp";
import img2 from "../../assets/newTrending/img2.jpg";
import img3 from "../../assets/newTrending/img3.webp";
import img4 from "../../assets/newTrending/img4.webp";
import img5 from "../../assets/newTrending/img5.webp";

export const products = [
  {
    label: "EXCLUSIVE",
    image: img1,
    title: "Tonal AOP Oversized T...",
    price: 991,
  },
  {
    label: "EXCLUSIVE",
    image: img2,
    title: "Embroidered Oversize...",
    price: 839,
  },
  {
    label: "EXCLUSIVE",
    image: img3,
    title: "Puff Print Oversized T...",
    price: 881,
  },
  {
    label: "EXCLUSIVE",
    image: img4,
    title: "Puff Print Oversized T...",
    price: 881,
  },
  {
    label: "EXCLUSIVE",
    image: img5,
    title: "Puff Print Oversized T...",
    price: 881,
  },
];
